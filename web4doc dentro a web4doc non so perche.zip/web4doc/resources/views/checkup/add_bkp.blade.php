@extends('templates.default')

@section('title', $title)

@section('content')

    {!! form($form) !!}

@endsection
