
	$(document).ready(function() {
		M.toast({html: '{{$slot}}'})
	});
