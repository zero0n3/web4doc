<div class="alert alert-info" role="alert">
  <a class="waves-effect waves-light btn">{{$slot}}</a>
</div>
