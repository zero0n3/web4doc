<?php

//#fattoamano

Route::get('welcome', 'PageController@welcome');   //-> qui uso il comando per creare un Controller da riga di comando

